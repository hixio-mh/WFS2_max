English:
Here are a couple of patches to allow a Contour ShuttleXpress controler to interact with some functions of the wave field synthesis system and cue lists in QLab.
It will be necessary to adjust the IP and ports according to your system.

Windows : pure-data vanilla 0.48 with hidin library retrieved with Deken.
MacOS : pure-data extended 0.43


Français : 
Voici deux patchs pour permettre à un contrôleur ShuttleXpress de Contour de piloter certaines fonctions du système de synthèse de front d'onde et la conduite de QLab.
Il faudra sans doute modifier les IP et ports en fonction de votre système.

Windows : pure-data vanilla 0.48 avec la librairie hidin récupérée par Deken.
MacOS : pure-data extended 0.43
