English:
Here is a layout for Lemur.
It was developed for an iPad. It may be necessary to adjust it depending on your screen aspect ratio and resolution on an Android Tablet.

Français :
Voici un fichier de configuration pour Lemur.
La disposition a été développée pour un iPad. Sur un tablette Android il sera certainement nécessaire de la retoucher en fonction de la résolution et de rapport entre hauteur et largeur de l'écran.
