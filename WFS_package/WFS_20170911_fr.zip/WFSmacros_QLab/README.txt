English:
Here is a template for QLab 4 with macros to create specific OSC commands for the WFS system.
Some of the macros are long scripts and will require a few seconds to execute.

Français :
Voici un modèle pour QLab 4 avec des macros pour créer des commandes OSC spécifiques au système WFS.
Certaines macros sont des scripts assez longs qui demandent quelques secondes pour s'exécuter.
