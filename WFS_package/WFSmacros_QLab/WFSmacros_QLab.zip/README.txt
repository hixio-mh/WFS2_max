﻿Updated/Mise à jour 2017-11-08




English:
Here are some templates for QLab 4 and QLab 3 with macros to create specific OSC commands for the WFS system.
Some of the macros are long scripts and will require a few seconds to execute.

Also included the same scripts turned into applications to be triggered by a key pad such as El Gato’s Streamdeck (templates included, but macros may need relinking unless you place the WFS_StreamDeck_Scripts in ~/Library/ ).




Français :
Voici des modèles pour QLab 4 et QLab 3 avec des macros pour créer des commandes OSC spécifiques au système WFS.
Certaines macros sont des scripts assez longs qui demandent quelques secondes pour s'exécuter.

Les mêmes scripts mais sous forme d’application sont également inclus. Ils peuvent être déclenchés par un clavier tel que le El Gate StreamDeck (modèles fournis, mais les adresses des macros pourront avoir besoin d’être recrées à moins de déposer WFS_StreamDeck_Scripts dans ~/Library/ ).




https://www.elgato.com/gaming/stream-deck/welcome?
